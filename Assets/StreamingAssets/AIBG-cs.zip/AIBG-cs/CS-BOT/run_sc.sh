SCRIPT_DIR=$(cd "$(dirname "$0")"; pwd) && dotnet run "$SCRIPT_DIR/Program.cs" --project $SCRIPT_DIR
